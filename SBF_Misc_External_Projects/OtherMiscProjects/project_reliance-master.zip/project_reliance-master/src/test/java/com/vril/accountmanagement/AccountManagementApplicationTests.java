package com.vril.accountmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
