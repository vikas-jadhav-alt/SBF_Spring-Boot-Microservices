package com.vril.accountmanagement;

class SingletonTest {

	private static SingletonTest INSTANCE;

	private SingletonTest() {
//		INSTANCE = new SingletonTest();
	}

	static SingletonTest getInstance() {
		if (INSTANCE == null)
			INSTANCE = new SingletonTest();

		return INSTANCE;
	}

}
